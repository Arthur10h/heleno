var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["848314f8-d7dc-4755-a4a1-3782173096b1","26b80e63-bc0f-408d-b288-be2282aebd4e","dfc53be7-786c-4305-b8eb-81fa595e9903","47fade86-5bd1-4789-87af-896fb1433a7b","043deebf-64b8-4795-be8d-db5055414f2f","c4e310e0-8174-4127-a46e-0cbcc94b488b","1e6ef369-5cae-492a-92be-63c38a634c48","b5895b3b-9b7f-4f97-8ff6-8fc4428d8081","bdd9ebf4-b1e1-486b-81b7-cd6a25007d15","5528e478-ddf2-4f55-b29e-f37f94a6a831","5285360b-12d4-487d-8530-054433805e92","334cc2e4-c27a-4753-81ab-f7810bf60f28","3958dbab-e81c-4dc3-b225-1e73852a5769"],"propsByKey":{"848314f8-d7dc-4755-a4a1-3782173096b1":{"name":"hero","sourceUrl":null,"frameSize":{"x":30,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"J5e4nLLxQCiqA_WtpNDr_4ihaAkz7Q0_","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":30},"rootRelativePath":"assets/848314f8-d7dc-4755-a4a1-3782173096b1.png"},"26b80e63-bc0f-408d-b288-be2282aebd4e":{"name":"enemy1","sourceUrl":null,"frameSize":{"x":35,"y":50},"frameCount":1,"looping":true,"frameDelay":12,"version":"4bVFsvDBh4BY8HVlakdbf3B75e9gN3QM","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":35,"y":50},"rootRelativePath":"assets/26b80e63-bc0f-408d-b288-be2282aebd4e.png"},"dfc53be7-786c-4305-b8eb-81fa595e9903":{"name":"enemy","sourceUrl":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png","frameSize":{"x":320,"y":254},"frameCount":1,"looping":true,"frameDelay":2,"version":"xasculQGiYxBV79ltD_0E79ZRIexdPdZ","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":320,"y":254},"rootRelativePath":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png"},"47fade86-5bd1-4789-87af-896fb1433a7b":{"name":"enemy2","sourceUrl":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png","frameSize":{"x":355,"y":241},"frameCount":1,"looping":true,"frameDelay":2,"version":"dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":355,"y":241},"rootRelativePath":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png"},"043deebf-64b8-4795-be8d-db5055414f2f":{"name":"enemy3","sourceUrl":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png","frameSize":{"x":388,"y":388},"frameCount":1,"looping":true,"frameDelay":2,"version":"YSis4_lex43su6FLaL__bhoag4eHAl8D","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":388,"y":388},"rootRelativePath":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png"},"c4e310e0-8174-4127-a46e-0cbcc94b488b":{"name":"dream","sourceUrl":null,"frameSize":{"x":386,"y":268},"frameCount":1,"looping":true,"frameDelay":12,"version":"Ez0mekTo95o8cpgQQjczHKoFUCJSh7Ye","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":386,"y":268},"rootRelativePath":"assets/c4e310e0-8174-4127-a46e-0cbcc94b488b.png"},"1e6ef369-5cae-492a-92be-63c38a634c48":{"name":"tropicalfish_19_1","sourceUrl":"assets/api/v1/animation-library/gamelab/LA7ASZMwvopz5uz8ymr0D.iS_zlXVEGq/category_animals/tropicalfish_19.png","frameSize":{"x":400,"y":229},"frameCount":1,"looping":true,"frameDelay":2,"version":"LA7ASZMwvopz5uz8ymr0D.iS_zlXVEGq","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":229},"rootRelativePath":"assets/api/v1/animation-library/gamelab/LA7ASZMwvopz5uz8ymr0D.iS_zlXVEGq/category_animals/tropicalfish_19.png"},"b5895b3b-9b7f-4f97-8ff6-8fc4428d8081":{"name":"ship05_1","sourceUrl":null,"frameSize":{"x":291,"y":291},"frameCount":1,"looping":true,"frameDelay":12,"version":"r0qPBJmVnMiu6aN9u5MYTufCj1fLzMV.","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":291,"y":291},"rootRelativePath":"assets/b5895b3b-9b7f-4f97-8ff6-8fc4428d8081.png"},"bdd9ebf4-b1e1-486b-81b7-cd6a25007d15":{"name":"bg_landscape21_1","sourceUrl":"assets/api/v1/animation-library/gamelab/GTrVmut4s5PswM6hx254yCcDWLNhhmVk/category_backgrounds/bg_landscape21.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"GTrVmut4s5PswM6hx254yCcDWLNhhmVk","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/GTrVmut4s5PswM6hx254yCcDWLNhhmVk/category_backgrounds/bg_landscape21.png"},"5528e478-ddf2-4f55-b29e-f37f94a6a831":{"name":"playerShip2_blue_1","sourceUrl":"assets/api/v1/animation-library/gamelab/o6MhvPFlxWIVVxxNBdRQQ9Cjv4HeJmYW/category_vehicles/playerShip2_blue.png","frameSize":{"x":112,"y":75},"frameCount":1,"looping":true,"frameDelay":2,"version":"o6MhvPFlxWIVVxxNBdRQQ9Cjv4HeJmYW","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":112,"y":75},"rootRelativePath":"assets/api/v1/animation-library/gamelab/o6MhvPFlxWIVVxxNBdRQQ9Cjv4HeJmYW/category_vehicles/playerShip2_blue.png"},"5285360b-12d4-487d-8530-054433805e92":{"name":"ore_coal_1","sourceUrl":"assets/api/v1/animation-library/gamelab/EXwnEiZdteOE6ff6APB3RBor0vYegUVU/category_video_games/ore_coal.png","frameSize":{"x":128,"y":128},"frameCount":1,"looping":true,"frameDelay":2,"version":"EXwnEiZdteOE6ff6APB3RBor0vYegUVU","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":128},"rootRelativePath":"assets/api/v1/animation-library/gamelab/EXwnEiZdteOE6ff6APB3RBor0vYegUVU/category_video_games/ore_coal.png"},"334cc2e4-c27a-4753-81ab-f7810bf60f28":{"name":"ufoBlue_1","sourceUrl":"assets/api/v1/animation-library/gamelab/Mm_U04vWjYgiMntQGcHd1Zc680jjaRjJ/category_vehicles/ufoBlue.png","frameSize":{"x":91,"y":91},"frameCount":1,"looping":true,"frameDelay":2,"version":"Mm_U04vWjYgiMntQGcHd1Zc680jjaRjJ","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":91,"y":91},"rootRelativePath":"assets/api/v1/animation-library/gamelab/Mm_U04vWjYgiMntQGcHd1Zc680jjaRjJ/category_vehicles/ufoBlue.png"},"3958dbab-e81c-4dc3-b225-1e73852a5769":{"name":"alien_03_1","sourceUrl":"assets/api/v1/animation-library/gamelab/mj2ti2iXM44mDQz.rcLgzlE_41.J15kR/category_fantasy/alien_03.png","frameSize":{"x":389,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"mj2ti2iXM44mDQz.rcLgzlE_41.J15kR","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":389,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/mj2ti2iXM44mDQz.rcLgzlE_41.J15kR/category_fantasy/alien_03.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----


var b = createSprite(200,200);
 b.setAnimation("bg_landscape21_1");
var hero = createSprite(200,345,200,345);

var enemy1 = createSprite(200,250,10,10);
enemy1.shapeColor="red";

var enemy2 = createSprite(200,150,10,10);
enemy2.shapeColor="red";

var enemy3 = createSprite(200,50,10,10);
enemy3.shapeColor="red";

var net = createSprite(200,5,200,20);
net.setAnimation("ufoBlue_1");
net.scale=.6;

var goal =0;
var death = 0;

hero.setAnimation("playerShip2_blue_1");
hero.scale=.5;
enemy1.setAnimation("ore_coal_1");
enemy1.scale=.4;
enemy2.setAnimation("ore_coal_1");
enemy2.scale=.4;
enemy3.setAnimation("ore_coal_1");
enemy3.scale=.4;

enemy1.setVelocity(-10,0);
enemy2.setVelocity(10,0);
enemy3.setVelocity(-10,0);


function draw() {
background("whith");
     


createEdgeSprites()




enemy1.bounceOff(edges);
enemy2.bounceOff(edges);
enemy3.bounceOff(edges);

if(keyDown(UP_ARROW)){
  hero.y=hero.y-3
}

if(keyDown(DOWN_ARROW)){
  hero.y=hero.y+3
}

if(keyDown(LEFT_ARROW)){
  hero.x=hero.x-3
}

if(keyDown(RIGHT_ARROW)){
  hero.x=hero.x+3
}

if(hero.isTouching(enemy1)|| hero.isTouching(enemy2)|| hero.isTouching(enemy3)){
  playSound("assets/category_achievements/bubbly_game_achievement_sound.mp3")
  hero.x=200
  hero.y=350
  death = death+1
}
if(hero.isTouching(net)){
  playSound("assets/category_achievements/vibrant_game_game_gold_tresure_chest_open.mp3")
  hero.x=200
  hero.y=345
  goal=goal+1
}
textSize(20)
  fill("blue")
  text("Objetivos:"+goal,320,350);
  

textSize(20)
  fill("black")
  
  
drawSprites()

  textSize(20)
  fill("whith")
  text("pontuaçao:"+goal,264,20);
  

  textSize(20)
  fill("black")






}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
